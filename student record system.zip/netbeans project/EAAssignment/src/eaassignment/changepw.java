
package eaassignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import static eaassignment.login.account;
import static eaassignment.login.password;

public class changepw extends javax.swing.JFrame {

    
    public changepw() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lnew = new javax.swing.JLabel();
        lconf = new javax.swing.JLabel();
        tconf = new javax.swing.JPasswordField();
        tpass = new javax.swing.JPasswordField();
        bexit = new javax.swing.JButton();
        bok = new javax.swing.JButton();
        bcheck = new javax.swing.JButton();
        tcurrent = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setText("Change Password");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Current Password");

        lnew.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lnew.setText("New Password");
        lnew.setEnabled(false);

        lconf.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lconf.setText("Confirm password");
        lconf.setEnabled(false);

        tconf.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tconf.setEnabled(false);

        tpass.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tpass.setEnabled(false);

        bexit.setText("Exit");
        bexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bexitActionPerformed(evt);
            }
        });

        bok.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        bok.setText("OK");
        bok.setEnabled(false);
        bok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bokActionPerformed(evt);
            }
        });

        bcheck.setText("Check");
        bcheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcheckActionPerformed(evt);
            }
        });

        tcurrent.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(bexit)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bok, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(98, 98, 98))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lconf)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lnew, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(81, 81, 81)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tpass)
                                    .addComponent(tconf, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(tcurrent)))
                            .addComponent(bcheck, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGap(54, 54, 54))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(bexit)
                .addGap(19, 19, 19)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tcurrent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bcheck)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lnew)
                    .addComponent(tpass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lconf)
                    .addComponent(tconf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(bok)
                .addGap(27, 27, 27))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
     private void changePassword(){
    
      String sql = "UPDATE logindata SET password = ? WHERE username = ?;";
        try 
        {		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
		PreparedStatement ps;
                ps=con.prepareStatement(sql);
                  ps.setString(1, tpass.getText());
		  ps.setString(2, account);		
                  ps.executeUpdate();
                  
                  JOptionPane.showMessageDialog(null,"Password Changed Successfully!", "", JOptionPane.WARNING_MESSAGE);    
                con.close();
	} 
        catch (Exception e)
        {
           JOptionPane.showMessageDialog(null,"Error! Enter valid data!", "", JOptionPane.ERROR_MESSAGE);    
	   e.printStackTrace();
	}  
    }  
    
    
    private void bexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bexitActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_bexitActionPerformed

    private void bokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bokActionPerformed
        if(tcurrent.getText().equals("") || tpass.getText().equals("") || tconf.getText().equals("")){
          JOptionPane.showMessageDialog(null,"Fill the empty fields!", "", JOptionPane.WARNING_MESSAGE);
       }
       
       else if(!tpass.getText().equals(tconf.getText())){
          JOptionPane.showMessageDialog(null,"Password missmatch!", "", JOptionPane.WARNING_MESSAGE);
       }  
       
       else{
         changePassword();
       }
    }//GEN-LAST:event_bokActionPerformed

    private void bcheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcheckActionPerformed
       if(tcurrent.getText().equals(password)){
         lnew.setEnabled(true);
         lconf.setEnabled(true);
         tpass.setEnabled(true);
         tconf.setEnabled(true);
         bok.setEnabled(true);
       }
       
       else{
        JOptionPane.showMessageDialog(null,"Wrong Password!", "", JOptionPane.ERROR_MESSAGE);
       }
    }//GEN-LAST:event_bcheckActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(changepw.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(changepw.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(changepw.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(changepw.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new changepw().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bcheck;
    private javax.swing.JButton bexit;
    private javax.swing.JButton bok;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lconf;
    private javax.swing.JLabel lnew;
    private javax.swing.JPasswordField tconf;
    private javax.swing.JPasswordField tcurrent;
    private javax.swing.JPasswordField tpass;
    // End of variables declaration//GEN-END:variables
}
