
package eaassignment;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class removeAdmin extends javax.swing.JFrame {
    static String user;
    
    public removeAdmin() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        bremove = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        rmvCombo = new javax.swing.JComboBox<>();
        bexit = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setText("Remove Admin");

        bremove.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        bremove.setText("Remove Admin");
        bremove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bremoveActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Select Username");

        rmvCombo.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        rmvCombo.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                rmvComboPopupMenuWillBecomeVisible(evt);
            }
        });
        rmvCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rmvComboActionPerformed(evt);
            }
        });

        bexit.setText("Exit");
        bexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bexitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(bexit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(129, 129, 129))
            .addGroup(layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bremove, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(rmvCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(58, 58, 58))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel4))
                    .addComponent(bexit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(rmvCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(61, 61, 61)
                .addComponent(bremove, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void eliminateDuplicates()
    {
        int stats=1;
        for(int i=0;i<rmvCombo.getItemCount();i++)
       {
        String cbitem=rmvCombo.getItemAt(i);
        if(cbitem.equals(user))
        {
          stats=0;
          break;
        }
       }//for
        
        if(stats==1)
        {
         rmvCombo.addItem(String.valueOf(user));
        }
     }    
    
    
    private void loadIndexes(){                          
        String sql= "SELECT username FROM logindata;";
        try 
        {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
		PreparedStatement ps;
                ps=con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                  while (rs.next()) 
                  {      
                   user = rs.getString("username");                   
                   eliminateDuplicates();                    
                  }
                con.close();
	} 
        catch (Exception e)
        {
	   e.printStackTrace();
	}       
    }   
    
    private void delete(){
       String sql = "DELETE FROM logindata WHERE username = ?";
       
       try 
        {		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
		PreparedStatement ps;
                ps=con.prepareStatement(sql);
                ps.setString(1, rmvCombo.getSelectedItem().toString());                                
                ps.executeUpdate();               
                con.close();
                JOptionPane.showMessageDialog(null,"Record Deleted Successfully!", "", JOptionPane.WARNING_MESSAGE);                 
	} 
        catch (Exception e)
        {
	   e.printStackTrace();
	}   
    }
    
    private void bremoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bremoveActionPerformed
       if(rmvCombo.getSelectedItem().toString().equals("Admin")) {
           JOptionPane.showMessageDialog(null,"Super Admin account cannot be deleted!", "", JOptionPane.ERROR_MESSAGE); 
       }
       
       else{
         int res = JOptionPane.showConfirmDialog(this, "Are you sure you want to remove this Admin?", "", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
         if(res == JOptionPane.YES_OPTION){
          delete();        
          rmvCombo.removeItemAt(rmvCombo.getSelectedIndex());
         }      
         else if(res == JOptionPane.NO_OPTION){
          JOptionPane.showMessageDialog(null,"Operation Canceled!", "", JOptionPane.WARNING_MESSAGE); 
         } 
       }
    }//GEN-LAST:event_bremoveActionPerformed
    
    private void rmvComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rmvComboActionPerformed

    }//GEN-LAST:event_rmvComboActionPerformed

    private void rmvComboPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_rmvComboPopupMenuWillBecomeVisible
       loadIndexes();
    }//GEN-LAST:event_rmvComboPopupMenuWillBecomeVisible

    private void bexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bexitActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_bexitActionPerformed
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(removeAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(removeAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(removeAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(removeAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new removeAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bexit;
    private javax.swing.JButton bremove;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JComboBox<String> rmvCombo;
    // End of variables declaration//GEN-END:variables
}
